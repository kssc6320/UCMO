create database CourseEnrolmentSystem;
use CourseEnrolmentSystem;

create table professor(
professor_id int auto_increment primary key,
name varchar(255) not null,
phone varchar(255) not null unique,
email varchar(255) not null unique,
password varchar(255) not null,
gender varchar(255) not null,
age    varchar(255) not null,
address varchar(255) not null
);

create table course(
coursprofessore_id int auto_increment primary key,
course_name varchar(255) not null,
course_description varchar(255) not null
);
create table student(
student_id int auto_increment primary key,
name varchar(255) not null,
phone varchar(255) not null unique,
email varchar(255) not null unique,
password varchar(255) not null,
gender varchar(255) not null,
age    varchar(255) not null,
address varchar(255) not null,
status varchar(255) not null default 'Deactivated'
);


create table section(
section_id int auto_increment primary key, 
section varchar(255) not null,
day varchar(255) not null,
CRN varchar(255) not null,
number_of_students_allowed varchar(255) not null,
course_id int,
professor_id int,
status varchar(255) default 'Active',
curriculum varchar(255),
foreign key(course_id)references course(course_id),
foreign key(professor_id)references professor(professor_id)
);
alter table section add curriculum varchar(255);

create table enrolments(
enrolment_id int auto_increment primary key, 
date varchar(255) not null,
status varchar(255) not null,
student_id int,
section_id int,
foreign key(section_id)references section(section_id),
foreign key(student_id)references student(student_id)
);