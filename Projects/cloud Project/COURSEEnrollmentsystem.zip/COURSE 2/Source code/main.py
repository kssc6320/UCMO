import os
import boto3
from flask import Flask, request, render_template, session, redirect
import pymysql
app = Flask(__name__)
conn = pymysql.connect(host="localhost", user="root", password="root", db="CourseEnrolmentSystem")
cursor = conn.cursor()
app.secret_key = 'fjsfdfd'
admin_username = 'admin'
admin_password = 'admin'
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = APP_ROOT+'/static/images'
region_name = 'us-east-2'
MyBucket = "curriculumuplodings"
source_email = 'kssc129@gmail.com'
s3_client = boto3.client('s3', aws_access_key_id="AKIAWYTUYZZ2UHTE52IR", aws_secret_access_key="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")
ses_client = boto3.client('ses', aws_access_key_id="AKIAWYTUYZZ2UHTE52IR", aws_secret_access_key="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", region_name=region_name)



@app.route("/")
def index():
    return render_template("index.html")


@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")


@app.route("/admin_login1")
def admin_login1():
    user_name = request.args.get("username")
    password = request.args.get("password")
    if admin_username == user_name and admin_password == password:
        session["role"] = 'admin'
        return redirect("/admin_home_page")
    else:
        return render_template("msg.html", message="Invalid Login Details")


@app.route("/admin_home_page")
def admin_home_page():
    return render_template("admin_home_page.html")


@app.route("/logout")
def logout():
    session.clear()
    return render_template("index.html")


@app.route("/student")
def student():
    return render_template("student.html")


@app.route("/student_registration")
def student_registration():
    name = request.args.get("name")
    phone = request.args.get("phone")
    email = request.args.get("email")
    password = request.args.get("password")
    gender = request.args.get("gender")
    age = request.args.get("age")
    address = request.args.get("address")
    count = cursor.execute("select * from student where email='" + str(email) + "' or phone='" + str(phone) + "'")
    if count == 0:
        verified_emails = ses_client.list_identities(
            IdentityType='EmailAddress'
        )
        if email in verified_emails['Identities']:
            subject = 'Hi' + '' + name + ' you have Registered Sucessfully'
            ses_client.send_email(Source=source_email, Destination={'ToAddresses': [email]}, Message={'Subject': {'Data': subject, 'Charset': 'utf-8'}, 'Body': {'Html': {'Data': subject, 'Charset': 'utf-8'}}})
            cursor.execute("insert into student(name,phone,email,password,gender,age,address) values('" + str(name) + "', '" + str(phone) + "', '" + str(email) + "', '" + str(password) + "', '" + str(gender) + "', '" + str(age) + "', '" + str(address) + "')")
            conn.commit()
            return render_template("msg.html", message="Student registered successfully")
        else:
            return render_template("msg.html", message="Your email is not verified by website.")
    else:
        return render_template("msg.html", message="Duplicate Details")


@app.route("/verify_email")
def verify_email():
    email = request.args.get("email")
    ses_client.verify_email_address(
        EmailAddress=email
    )
    return render_template("msg.html", message="Click on link that sent on your email and refresh the page")


@app.route("/student_login")
def student_login():
    return render_template("student_login.html")


@app.route("/student_login1")
def student_login1():
    email = request.args.get("email")
    password = request.args.get("password")
    count = cursor.execute("select * from student where email= '" + str(email) + "' and password= '" + str(password) + "'")
    students = cursor.fetchall()
    if count > 0:
        student = students[0]
        if student[8] == 'Verified':
            session["student_id"] = student[0]
            session["role"] = 'student'
            return redirect("/student_home")
        else:
            return render_template("msg.html", message="Your account not verified")
    else:
        return render_template("msg.html", message="Invalid login")


@app.route("/view_students")
def view_students():
    cursor.execute("select * from student")
    students = cursor.fetchall()
    return render_template("view_students.html", students=students)


@app.route("/verify_student")
def verify_student():
    student_id = request.args.get("student_id")
    cursor.execute("update student set status = 'Verified' where student_id = '" + str(student_id) + "' ")
    conn.commit()
    return redirect("/view_students")


@app.route("/add_professor")
def add_professor():
    return render_template("add_professor.html")


@app.route("/add_professor1")
def add_professor1():
    name = request.args.get("name")
    phone = request.args.get("phone")
    email = request.args.get("email")
    password = request.args.get("password")
    gender = request.args.get("gender")
    age = request.args.get("age")
    address = request.args.get("address")
    count = cursor.execute("select * from professor where email='"+str(email)+"' or phone='"+str(phone)+"'")
    if count == 0:
        cursor.execute("insert into professor(name,phone,email,password,gender,age,address) values('" + str(name) + "', '" + str(phone) + "', '" + str(email) + "', '" + str(password) + "', '" + str(gender) + "', '" + str(age) + "', '" + str(address) + "')")
        conn.commit()
        return render_template("admin_msg.html", message="Professor Added Successfully")
    else:
        return render_template("admin_msg.html", message="Duplicate Details")


@app.route("/view_professors")
def view_professors():
    cursor.execute("select * from professor")
    professors = cursor.fetchall()
    return render_template("view_professors.html", professors=professors)


@app.route("/add_course")
def add_course():
    return render_template("add_course.html")


@app.route("/add_course1")
def add_course1():
    course_name = request.args.get("name")
    course_name = course_name.upper()
    course_description = request.args.get("description")
    count = cursor.execute("select * from course where course_name='"+str(course_name)+"'")
    if count == 0:
        cursor.execute("insert into course(course_name, course_description) values('"+str(course_name)+"', '"+str(course_description)+"')")
        conn.commit()
        return render_template("admin_msg.html", message="Course is Added Successfully")
    else:
        return render_template("admin_msg.html", message="Course is Already Exits")


@app.route("/view_courses")
def view_courses():
    cursor.execute("select * from course")
    courses = cursor.fetchall()
    return render_template("view_courses.html", courses=courses)


@app.route("/add_section")
def add_section():
    course_id = request.args.get("course_id")
    if course_id == None:
        query = "select * from course"
    elif course_id != None:
        query = "select * from course where course_id='"+str(course_id)+"'"
    cursor.execute(query)
    courses = cursor.fetchall()
    cursor.execute("select * from professor")
    professors = cursor.fetchall()
    return render_template("add_section.html", courses=courses, professors=professors)


@app.route("/add_section1")
def add_section1():
    course_id = request.args.get("course_id")
    day = request.args.get("day")
    professor_id = request.args.get("professor_id")
    section = request.args.get("section")
    CRN = request.args.get("CRN")
    number_of_students_allowed = request.args.get("number_of_students_allowed")
    count = cursor.execute("select * from section where CRN = '" + str(CRN) + "'")
    if count == 0:
        if professor_id is None:
            professor_id = session['professor_id']
            cursor.execute("insert into section(course_id,day,professor_id,section,CRN,number_of_students_allowed) value('" + str(course_id) + "', '" + str(day) + "', '" + str(professor_id) + "', '" + str(section) + "', '" + str(CRN) + "', '" + str(number_of_students_allowed) + "')")
            conn.commit()
            return render_template("admin_msg.html", message="Section Added Successfully")
        else:
            cursor.execute("insert into section(course_id,day,professor_id,section,CRN,number_of_students_allowed) value('"+str(course_id)+"', '"+str(day)+"', '"+str(professor_id)+"', '"+str(section)+"', '"+str(CRN)+"', '"+str(number_of_students_allowed)+"')")
            conn.commit()
            return render_template("admin_msg.html", message="Section Added Successfully")
    else:
        return render_template("admin_msg.html", message="Section already exist")


@app.route("/view_sections")
def view_sections():
    role = session['role']
    course_id = request.args.get("course_id")
    if role == 'admin':
        if course_id == None:
            query = "select * from section"
        elif course_id != None:
            query = "select * from section where course_id='" + str(course_id) + "'"
    elif role == 'professor':
        professor_id = session["professor_id"]
        query = "select * from section where professor_id='"+str(professor_id)+"'"
    elif role == 'student':
        student_id = session['student_id']
        query = "select * from section where course_id='" + str(course_id) + "'"
    cursor.execute(query)
    sections = cursor.fetchall()
    return render_template("view_sections.html", sections=sections, get_course_by_course_id=get_course_by_course_id, get_professor_by_professor_id=get_professor_by_professor_id, get_enrolment_by_student_id_section_id=get_enrolment_by_student_id_section_id, get_enrolment_by_student_id=get_enrolment_by_student_id, get_enrolment_by_course=get_enrolment_by_course, get_enrolment_by_day=get_enrolment_by_day)


def get_course_by_course_id(course_id):
    cursor.execute("select * from course where course_id= '"+str(course_id)+"'")
    courses = cursor.fetchall()
    return courses[0]


def get_professor_by_professor_id(professor_id):
    cursor.execute("select * from professor where professor_id= '"+str(professor_id)+"'")
    professors = cursor.fetchall()
    return professors[0]


def get_student_by_student_id(student_id):
    cursor.execute("select * from student where student_id= '"+str(student_id)+"'")
    students = cursor.fetchall()
    return students[0]


def get_section_by_section_id(section_id):
    cursor.execute("select * from section where section_id= '"+str(section_id)+"'")
    sections = cursor.fetchall()
    return sections[0]


@app.route("/professor_login")
def professor_login():
    return render_template("professor_login.html")


@app.route("/professor_login1")
def professor_login1():
    email = request.args.get("email")
    password = request.args.get("password")
    count = cursor.execute("select * from professor where email= '" + str(email) + "' and password= '" + str(password) + "'")
    professors = cursor.fetchall()
    if count > 0:
        professor = professors[0]
        session["professor_id"] = professor[0]
        session["role"] = 'professor'
        return redirect("/professor_home")
    else:
        return render_template("msg.html", message="Invalid login")


@app.route("/professor_home")
def professor_home():
    return render_template("professor_home.html")



@app.route("/student_home")
def student_home():
    return render_template("student_home.html")


@app.route("/enrol")
def enrol():
    section_id = request.args.get("section_id")
    section = request.args.get("section")
    student_id = session["student_id"]
    cursor.execute("insert into enrolments(student_id, date, status, section_id) values('"+str(student_id)+"', now(), 'Enrolled', '"+str(section_id)+"')")
    conn.commit()
    cursor.execute("select * from student where student_id='"+str(student_id)+"'")
    students = cursor.fetchall()
    email = students[0][3]
    name = students[0][1]
    subject = 'Hi' + '' + name + ' you have enrolled to '+section+' Sucessfully'
    ses_client.send_email(Source=source_email, Destination={'ToAddresses': [email]},
                          Message={'Subject': {'Data': subject, 'Charset': 'utf-8'},
                                   'Body': {'Html': {'Data': subject, 'Charset': 'utf-8'}}})
    return render_template("student_msg.html", message="Enrolled Successfully")


@app.route("/view_enrolled_student")
def view_enrolled_student():
    section_id = request.args.get("section_id")
    if section_id == None:
        professor_id = session["professor_id"]
        query = "select * from enrolments where section_id in (select section_id from section where professor_id='" + str(professor_id) + "')"
    elif section_id != None:
        query = "select * from enrolments where section_id='"+str(section_id)+"'"
    cursor.execute(query)
    enrolments = cursor.fetchall()
    print(enrolments)
    return render_template("view_enrolled_student.html", enrolments=enrolments, get_student_by_student_id=get_student_by_student_id, get_section_by_section_id=get_section_by_section_id, get_course_by_course_id=get_course_by_course_id)


@app.route("/view_enrolled_courses")
def view_enrolled_courses():
    student_id = session["student_id"]
    cursor.execute("select * from enrolments where student_id='"+str(student_id)+"' and status='Enrolled'")
    enrolments = cursor.fetchall()
    return render_template("view_enrolled_courses.html", enrolments=enrolments, get_section_by_section_id=get_section_by_section_id, get_course_by_course_id=get_course_by_course_id, get_professor_by_professor_id=get_professor_by_professor_id)


@app.route("/upload_curriculum")
def upload_curriculum():
    section_id = request.args.get("section_id")
    return render_template("upload_curriculum.html", section_id=section_id)


@app.route("/upload_curriculum1", methods=['post'])
def upload_curriculum1():
    section_id = request.form.get("section_id")
    upload_curriculum = request.files.get("upload_curriculum")
    path = APP_ROOT + "/" + upload_curriculum.filename
    upload_curriculum.save(path)
    cursor.execute("update section set curriculum='"+str(upload_curriculum.filename)+"' where section_id='"+str(section_id)+"'")
    conn.commit()
    s3_client.upload_file(path, MyBucket, upload_curriculum.filename)
    return render_template("admin_msg.html", message="Uploaded Successfully")


@app.route("/view_curriculum")
def view_curriculum():
    section_id = request.args.get("section_id")
    cursor.execute("select * from section where section_id='"+str(section_id)+"'")
    sections = cursor.fetchall()
    curriculum = sections[0][8]
    return render_template("view_curriculum.html", curriculum=curriculum)


@app.route("/drop_enrol")
def drop_enrol():
    student_id = session["student_id"]
    enrolment_id = request.args.get("enrolment_id")
    print(enrolment_id)
    cursor.execute("select * from enrolments where enrolment_id='" + str(enrolment_id) + "'")
    enrolments = cursor.fetchall()
    section_id = enrolments[0][4]
    cursor.execute("select * from section where section_id='" + str(section_id) + "'")
    sections = cursor.fetchall()
    section = sections[0][1]
    cursor.execute("select * from student where student_id='" + str(student_id) + "'")
    students = cursor.fetchall()
    email = students[0][3]
    name = students[0][1]
    subject = 'Hi' + '' + name + ' you have dropped to ' + section + ' Sucessfully'
    ses_client.send_email(Source=source_email, Destination={'ToAddresses': [email]}, Message={'Subject': {'Data': subject, 'Charset': 'utf-8'},
                                                                            'Body': {'Html': {'Data': subject, 'Charset': 'utf-8'}}})
    cursor.execute("delete from enrolments where enrolment_id = '" + str(enrolment_id) + "'")
    conn.commit()
    return render_template("student_msg.html", message="Enrollment Dropped Successfully")


def get_enrolment_by_student_id_section_id(section_id):
    student_id = session["student_id"]
    cursor.execute("select * from enrolments where student_id= '"+str(student_id)+"' and section_id='"+str(section_id)+"' and status='Enrolled'")
    enrolments = cursor.fetchall()
    return enrolments[0]


def get_enrolment_by_student_id(section_id):
    student_id = session["student_id"]
    count = cursor.execute("select * from enrolments where student_id= '" + str(student_id) + "' and section_id='"+str(section_id)+"' and status='Enrolled'")
    if count == 0:
        return False
    else:
        return True


@app.route("/view_professor_profile")
def view_professor_profile():
    professor_id = session['professor_id']
    cursor.execute("select * from professor where professor_id='"+str(professor_id)+"'")
    professors = cursor.fetchall()
    return render_template("view_professor_profile.html", professors=professors)


@app.route("/view_student_profile")
def view_student_profile():
    student_id = session['student_id']
    cursor.execute("select * from student where student_id='"+str(student_id)+"'")
    students = cursor.fetchall()
    return render_template("view_student_profile.html", students=students)


@app.route("/update_student_password")
def update_student_password():
    student_id = request.args.get("student_id")
    return render_template("update_student_password.html", student_id=student_id)


@app.route("/update_professor_password")
def update_professor_password():
    professor_id = request.args.get("professor_id")
    return render_template("update_professor_password.html", professor_id=professor_id)


@app.route("/update_password1")
def update_password1():
    password = request.args.get("password")
    role = session['role']
    if role == 'professor':
        professor_id = session["professor_id"]
        cursor.execute("update professor set password = '"+str(password)+"' where professor_id = '" + str(professor_id) + "' ")
        conn.commit()
        return redirect("/view_professor_profile")
    elif role == 'student':
        student_id = session["student_id"]
        cursor.execute("update student set password = '"+str(password)+"' where student_id = '" + str(student_id) + "' ")
        conn.commit()
        return redirect("/view_student_profile")


@app.route("/update_curriculum")
def update_curriculum():
    section_id = request.args.get("section_id")
    print(section_id)
    return render_template("update_curriculum.html", section_id=section_id)


@app.route("/update_curriculum1", methods=['post'])
def update_curriculum1():
    section_id = request.form.get("section_id")
    upload_curriculum = request.files.get("upload_curriculum")
    path = APP_ROOT + "/" + upload_curriculum.filename
    upload_curriculum.save(path)
    print("update section set curriculum='" + str(upload_curriculum.filename) + "' where section_id='" + str(section_id) + "'")
    cursor.execute("update section set curriculum='"+str(upload_curriculum.filename)+"' where section_id='"+str(section_id)+"'")
    conn.commit()
    s3_client.upload_file(path, MyBucket, upload_curriculum.filename)
    return render_template("admin_msg.html", message="Curriculum is Update Successfully")


def get_enrolment_by_course(section_id):
    student_id = session["student_id"]
    print("select * from enrolments where section_id in (select section_id from section where course_id in (select course_id from section where section_id='"+str(section_id)+"')) and student_id='"+str(student_id)+"'")
    count = cursor.execute("select * from enrolments where section_id in (select section_id from section where course_id in (select course_id from section where section_id='"+str(section_id)+"')) and student_id='"+str(student_id)+"'")
    if count == 0:
        return False
    else:
        return True


def get_enrolment_by_day(section_id):
    student_id = session["student_id"]
    count = cursor.execute("select * from section where section_id='"+str(section_id)+"' and day not in (select day from section where section_id in (select section_id from enrolments where section_id='"+str(student_id)+"'))")
    if count > 0:
        return False
    else:
        return True


app.run(debug=True)
